import React, { useState } from "react";
import { StyleSheet, Text, TextInput, TouchableOpacity, View } from "react-native";

const BMICalculator = () => {
  const [weight, setWeight] = useState("");
  const [height, setHeight] = useState("");
  const [BMI, setBMI] = useState(0);
  const [BMICategory, setBMICategory] = useState(0);

  const computeBMI = () => {
    const weightInKg = parseFloat(weight);
    const heightInM = parseFloat(height) / 100;
    const bmi = weightInKg / (heightInM * heightInM);

    let bmiCategory = 0;
    if (bmi < 18.5) {
      bmiCategory = 1;
    } else if (bmi < 25) {
      bmiCategory = 2;
    } else if (bmi < 30) {
      bmiCategory = 3;
    } else {
      bmiCategory = 4;
    }

    setBMI(bmi);
    setBMICategory(bmiCategory);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>BMI Calculator</Text>
      <TextInput
        style={styles.input}
        placeholder="Chỉ số Cân Nặng (kg)"
        keyboardType="numeric"
        value={weight}
        onChangeText={(text) => setWeight(text)}
      />
      <TextInput
        style={styles.input}
        placeholder="Chiều Cao (cm)"
        keyboardType="numeric"
        value={height}
        onChangeText={(text) => setHeight(text)}
      />
      <TouchableOpacity style={styles.button} onPress={computeBMI}>
        <Text style={styles.buttonText}>Calculate BMI</Text>
      </TouchableOpacity>
      <Text style={styles.result}>
        BMI: {BMI.toFixed(2)} (Category: {BMICategory})
      </Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
  },
  input: {
    width: "80%",
    height: 40,
    borderColor: "#ccc",
    borderWidth: 1,
    padding: 10,
    margin: 10,
  },
  button: {
    width: "80%",
    height: 40,
    backgroundColor: "#000",
    color: "#fff",
    borderRadius: 5,
    alignItems: "center",
    justifyContent: "center",
    margin: 10,
  },
  buttonText: {
    fontSize: 16,
    fontWeight: "bold",
  },
  result: {
    fontSize: 18,
    fontWeight: "bold",
    margin: 10,
  },
});

export default BMICalculator;
